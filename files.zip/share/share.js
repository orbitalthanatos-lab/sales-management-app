document.addEventListener("DOMContentLoaded", initSharePage);

function initSharePage() {
    const items = getAvailableItems();
    renderItems(items);
}

function getAvailableItems() {
    const storedItems = JSON.parse(localStorage.getItem("items")) || [];

    return storedItems.filter(item => {
        const status = String(item.status || "").trim().toLowerCase();

        return [
            "available",
            "disponible"
        ].includes(status);
    });
}

function renderItems(items) {
    const grid = document.getElementById("itemsGrid");

    if (!grid) return;

    if (items.length === 0) {
        grid.innerHTML = `
            <div class="empty-state">
                <h2>No available items</h2>
                <p>There are currently no items to display.</p>
            </div>
        `;
        return;
    }

    grid.innerHTML = items.map(createItemCard).join("");
}

function createItemCard(item) {
    const title =
        item.title ||
        item.name ||
        item.itemName ||
        item.productName ||
        "Untitled Item";

    const price = formatPrice(
        item.salePrice ??
        item.price ??
        item.sellingPrice ??
        item.sellPrice ??
        0
    );

    const image = getImage(item);

    return `
        <article class="share-card">
            <img
                class="share-card-image"
                src="${image}"
                alt="${escapeHtml(title)}"
            />

            <div class="share-card-content">
                <h2 class="share-card-title">${escapeHtml(title)}</h2>
                <div class="share-card-price">${price}</div>
            </div>
        </article>
    `;
}

function getImage(item) {
    if (Array.isArray(item.images) && item.images.length > 0) {
        return item.images[0];
    }

    return "https://via.placeholder.com/600x400?text=No+Image";
}

function formatPrice(value) {
    const number = Number(value || 0);

    return new Intl.NumberFormat("en-GB", {
        style: "currency",
        currency: "EUR"
    }).format(number);
}

function escapeHtml(text) {
    const div = document.createElement("div");
    div.textContent = text;
    return div.innerHTML;
}